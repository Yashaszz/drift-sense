# Drift-Sense — R1 Progress Handoff

## Role & scope
Working **R1 = Geometry & Ground Truth** on PS-02 (navigation-error recovery, wafer inspection). R1 owns `layouts.py`, `render.py`, `generate_dataset.py`, plus RGB bonus later. R1 is the load-bearing role: any coordinate-convention or half-pixel bug here silently caps *everyone's* accuracy downstream.

## Key decision locked: build BOTH DRAM and FinFET
The PS says "participant's choice, judged equally either way" — but that only covers the 30%-weight augmentation-realism showcase. The 50%-weight accuracy score runs on a held-out test set **not guaranteed to match your chosen architecture**, and the matcher must be architecture-agnostic. Building only one risks half the score on an unsupported assumption. Decision: build both, DRAM first (anchors come naturally as via defects; matches the sample GT schema), FinFET ported in after on the same scaffolding.

## Deliverable produced
A single **fully-executed Jupyter notebook** (`DriftSense_R1_Phase0_Phase1.ipynb`, 27 cells: 15 markdown + 12 code) covering Phase 0 + Phase 1, with all outputs embedded. Runs clean top-to-bottom via `nbconvert` (verified). Submission format is notebook, so every section = markdown + code + inline visual/printed sanity check, no hidden state.

## What's in it

### Phase 0 (foundations, locked before code)
- Coordinate convention: pixel-center origin, pixel (i,j) center at (j+0.5, i+0.5), `px = nm/nm_per_px`. Ref = 1 nm/px, search = 10 nm/px (**10× linear, not area**). GT `(x,y)` = reference crop center in search-image pixel space as **float/sub-pixel**, matching spec sample format.
- Layout schema: `{pattern (analytic periodic), erase, overrides, anchors, meta}`.
- GT JSONL schema + `validate_gt_record` guard.
- **Frozen physics seam:** `apply_sem_chain(img, px_nm, params, rng)` — R2's module, currently identity passthrough stub. Contracted order: edge_brighten → PSF → Poisson → read_noise → scan_artifacts, applied independently per capture.
- Metrics: `success_at_tolerance` (tol=1px), `recall_at_k`, `top1_given_recall` (split deliberately so weak matcher vs weak disambiguator can't be blamed on each other).
- Open questions for organizers (10× linear confirm, tie-break rule, test-set architecture coverage, tolerance number, timing measurement basis).
- Module-ownership stub table.

### Phase 1 (generator + first numbers)
- `generate_dram_layout` — orthogonal/staggered word-line/bit-line grid + via at each intersection. 3 anchors: missing_via, oversized_via, shifted_via. `anchored=False` deliberately reproduces the ambiguous/tie failure case.
- `generate_finfet_layout` — parallel fins + 1–2 gate bars. 3 anchors: missing_fin, merged_fin, gate_break.
- `rasterize` / `make_pair` — two-scale, area-averaged (supersample-then-mean, never bicubic/Lanczos), rotation applied to the **sampling window** not the finished raster (keeps GT exact by construction).
- GT overlay validation: reconstruct reference using *only* search image + GT → confirmed pixel-perfect alignment (residual is just interpolation edge-blur, mean|err|≈0.08–0.15, no positional offset).
- `generate_stratified_dataset` — stratified over architecture × anchor × pose_condition, 3 seeds/cell → **36 pairs, perfectly balanced** (dram 18/finfet 18, anchored 18/unanchored 18, pose none/small/large 12 each), emits `ground_truth.jsonl`.
- Final overlay-verify on 3 random samples from actual generated files (different strata, not cherry-picked).

## Critical performance lesson (don't lose this)
First renderer looped over every individual shape object (~4,700 shapes × 16M supersampled points) → **15–20s per image**, unusable. Rewrote to evaluate the periodic pattern **analytically via vectorized modular arithmetic** (one array pass), looping only over the ~3 anchor overrides → **~1–3s/pair**. If you scale up in Phase 2, resist "just add more shapes to the list" — it brings the slowdown straight back. Also used float32 throughout + an axis-aligned fast path for rotation=0.

## Environment notes
- Built/tested on: numpy 2.4.4, PIL 12.1.1, scipy 1.17.1, matplotlib 3.10.8 (your machine: Python 3.14, numpy 2.5.1 etc. — all compatible).
- Needed installs: `notebook jupyterlab ipykernel matplotlib nbconvert nbformat nbclient`.
- Supersample default = 4; GT reconstruction uses `scipy.ndimage.map_coordinates`.

## Not yet done (out of R1 Phase 0/1 scope)
Noise (physics stub only), pose estimation, disambiguation, matching — all downstream. RGB bonus deferred.

## Next steps (Phase 2, R1 slice)
1. Scale 36 → 100+ pairs.
2. Widen domain randomization (baseline: pitch ±20%, linewidth ±15%, rotation ±5°, scale ±3%; `large` pose already exceeds this for stress).
3. Hand frozen `apply_sem_chain` seam to R2 when `sem_physics.py` lands — re-run dataset cell unchanged.
4. Add a harsher noise stratum once physics is real.

---

To resume elsewhere, paste this summary in and mention you want to continue R1. One caveat: a new chat won't have the actual notebook file or generated images in its workspace — if you want to keep iterating on the code, either re-upload the `.ipynb` or ask to regenerate the pipeline from this summary (the logic is fully specified above, so rebuilding is straightforward).
