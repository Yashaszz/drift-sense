# Drift-Sense — R1 Geometry & Ground Truth (rev. 3)

Corrected deliverable. Two ground-truth defects found and fixed; both now covered
by fatal assertions so they cannot silently return.

## Contents

```
DriftSense_R1_Phase0_Phase1_FIXED.ipynb   Phase 0 + Phase 1, 29 cells, runs clean top-to-bottom
DriftSense_R1_Handoff.md                  role/scope handoff summary
dataset/
  ground_truth.jsonl                      36 records, regenerated with corrected GT
  reference/*.png                         36 reference crops  (1000x1000, ~1 nm/px)
  search/*.png                            36 search images    (1000x1000, ~10 nm/px)
figures/
  gt_halfpixel_before_after.png           the +0.5 px bug, same pair, GT value only difference
  gt_containment_before_after.png         2.6% out-of-bounds -> 0%, 20k-draw Monte Carlo
  diagram_pixel_center.png                why half-integer pixel centres
  diagram_rotation_method.png             rotate sampling window vs rotate finished raster
  dram_finfet_reference_search_pairs.png  visual sanity check, both architectures
  ground_truth_overlay_reconstruction.png reconstruct reference from search+GT only
  overlay_verify_random_samples.png       same check on 3 random pairs from the real dataset
```

## Answers to R1's three open asks

**1. Integer or half-integer pixel centres?**
Half-integer. `rasterize` samples pixel `k` at continuous position `k + 0.5`, so
the window centre is at index `out_size/2 - 0.5` — **499.5** for a 1000 px image.
`x = col`, `y = row`, 0-indexed, origin top-left.

*This ask found a live bug.* `make_pair` was basing ground truth at `out_size/2`,
putting a constant **+0.5 px offset in both axes on every pair ever emitted**:
0.707 px radial, 71% of the 1 px success tolerance and 50x R2's 0.01 px
measurement precision. Fixed; `ground_truth.jsonl` regenerated.

**2. `generate_dataset.py` output.**
36 pairs (meets >=36) plus `ground_truth.jsonl`, one JSON object per line with
image paths, true centre `(x, y)`, applied `theta` (`rotation_deg`), applied
`scale`, noise stratum, and architecture. Format was already correct; the
`(x, y)` values were not, and have been regenerated.

**3. Can the reference region be clipped at a search-image edge?**
Previously yes — and it could fall outside the search image entirely. Reference
and search centres were drawn independently with no containment constraint:
**2.6% of draws fully out of bounds, 10.5% clipped** (20,000-draw Monte Carlo).
Now **guaranteed contained by construction** and asserted per record. Pass
`allow_edge_clipping=True` to `make_pair` if R4 wants clipped stress cases for
T6 — explicit opt-in, never an accident.

## The two fixes

**FIX 1 — half-pixel GT base.** `make_pair` now uses `pixel_centre_base(out_size)`
= `out_size/2 - 0.5`.

**FIX 2 — containment by inverse sampling.** Rather than drawing the reference
and search centres independently and hoping, `make_pair` samples the GT position
directly in search-pixel space inside a safe band (reference footprint's rotated
half-diagonal + 8 px pad), then solves backwards for the world crop centre.

## Regression guards (notebook section 1.6a)

**Guard A — zero-offset identity.** Render one image, use it as both reference
and search at the same resolution, reconstruct it from its own ground truth. With
the correct base the resampling grid lands on exact integer indices, so the result
must be bit-for-bit identical:

| GT base | mean absolute error |
|---|---|
| `out_size/2 - 0.5` = 499.5 (fixed) | **0.000000** |
| `out_size/2` = 500.0 (old bug) | 0.043162 |

No tolerance to argue about — it is either exact or the convention is wrong.

**Guard B — forward/inverse agreement.** The inverse sampler (GT -> world centre)
and the forward formula (world centre -> GT) must be exact inverses. Over 200,000
randomised poses (rotation +-8 deg, scale 0.95-1.05) the worst disagreement is
**2.6e-13 px**, float64 noise, ~10 orders of magnitude below R2's 0.01 px precision.

Plus per-record guards in `validate_gt_record`: GT inside `[0, out_size)`, and the
full reference footprint contained using the rotated bounding half-diagonal.

## Regenerated dataset

36 pairs, strata still perfectly balanced:

- architecture: dram 18 / finfet 18
- anchor: anchored 18 / unanchored 18
- pose_condition: none 12 / small 12 / large 12
- noise_level: none 36 (physics stub pending R2)

GT ranges: x in [98.16, 901.37], y in [120.77, 839.53] — all records pass the new
in-bounds and containment guards.

Overlay reconstruction error across all 36: min 0.0571, mean 0.0750, max 0.1044
(down from 0.081-0.153). The residual is bilinear-interpolation blur from the 10x
coarser search resolution, not positional misalignment. On one isolated matched
pair the fix alone took the error from 0.1047 to 0.0689, a 34% reduction.

## Environment

numpy, PIL/Pillow, matplotlib; scipy optional — the notebook falls back to a
pure-numpy bilinear resampler if `scipy.ndimage` is unavailable, so it runs on a
clean machine without changing any result.

## Still out of R1 Phase 0/1 scope

Noise (physics seam is a passthrough stub), pose estimation, disambiguation,
matching. RGB bonus deferred.

## Next (Phase 2, R1 slice)

1. Scale 36 -> 100+ pairs.
2. Widen domain randomization (pitch +-20%, linewidth +-15%, rotation +-5%,
   scale +-3% baseline; `large` pose already exceeds this).
3. Hand the frozen `apply_sem_chain` seam to R2 when `sem_physics.py` lands and
   re-run the dataset cell unchanged.
4. Add a harsher noise stratum once physics is real.
